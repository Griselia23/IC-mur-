# ic-mur > 2025-01-17 3:42pm
https://universe.roboflow.com/autocounter-object-detection/ic-mur

Provided by a Roboflow user
License: CC BY 4.0

